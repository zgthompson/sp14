//  Zachary Thompson

//  MoviesAtTheaterTableViewController.h
//  TableViewDemoPart1
//
//  Created by student on 3/25/14.
//  Copyright (c) 2014 Ali Kooshesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoviesAtTheaterTableViewController : UITableViewController

-(id) initWithStyle:(UITableViewStyle) style andMovies:(NSArray *) movies;

@end
