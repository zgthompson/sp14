//  Zachary Thompson

//  City.h
//  TableViewDemoPart1
//
//  Created by student on 3/24/14.
//  Copyright (c) 2014 Ali Kooshesh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject

-(id) initWithDictionary: (NSDictionary *) dictionary;

- (NSString *) cityName;

@end
