//  Zachary Thompson

//  TheatersTableViewController.h
//  TableViewDemoPart1
//
//  Created by AAK on 3/9/14.
//  Copyright (c) 2014 Ali Kooshesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TheatersTableViewController : UITableViewController

@end
