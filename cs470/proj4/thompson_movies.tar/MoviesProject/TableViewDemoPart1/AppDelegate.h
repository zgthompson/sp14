//  Zachary Thompson

//  AppDelegate.h
//  TableViewDemoPart1
//
//  Created by AAK on 3/7/14.
//  Copyright (c) 2014 Ali Kooshesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
