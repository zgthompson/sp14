//
//  FifteenPuzzleTests.h
//  FifteenPuzzleTests
//
//  Created by student on 2/8/14.
//  Copyright (c) 2014 zgt. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface FifteenPuzzleTests : SenTestCase

@end
