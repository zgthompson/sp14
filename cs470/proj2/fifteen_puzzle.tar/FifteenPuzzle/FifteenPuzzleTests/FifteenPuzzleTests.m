//
//  FifteenPuzzleTests.m
//  FifteenPuzzleTests
//
//  Created by student on 2/8/14.
//  Copyright (c) 2014 zgt. All rights reserved.
//

#import "FifteenPuzzleTests.h"

@implementation FifteenPuzzleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in FifteenPuzzleTests");
}

@end
