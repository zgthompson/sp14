//  Additions made by Zachary Thompson
//  MatchScore.h
//  TennisInObjectiveC
//
//  Created by student on 2/3/14.
//  Copyright (c) 2014 Ali Kooshesh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Score.h"

@interface MatchScore : Score

-(void) addSetScore: (Score *) score;

@end
