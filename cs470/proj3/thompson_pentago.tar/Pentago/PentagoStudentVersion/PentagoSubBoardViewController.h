//
//  PentagoSubBoardViewController.h
//  PentagoStudentVersion
//
//  Zachary Thompson
//
//

#import <UIKit/UIKit.h>

@interface PentagoSubBoardViewController : UIViewController
-(id) initWithSubsquare: (int) position;
@end
