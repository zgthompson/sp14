//
//  PentagoViewController.h
//  PentagoStudentVersion
//
// Zachary Thompson
//

#import <UIKit/UIKit.h>

@interface PentagoViewController : UIViewController

@end
